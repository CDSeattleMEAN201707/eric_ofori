export class Mail {
}
