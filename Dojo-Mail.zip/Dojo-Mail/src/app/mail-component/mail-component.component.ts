import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-component',
  templateUrl: './mail-component.component.html',
  styleUrls: ['./mail-component.component.css']
})
export class MailComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
